// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:timeline_list/timeline.dart';
// import 'package:timeline_list/timeline_model.dart';
//
// List<TimelineModel> items = [
//   TimelineModel(Placeholder(),
//       position: TimelineItemPosition.random,
//       iconBackground: Colors.redAccent,
//       icon: Icon(Icons.blur_circular)),
//   TimelineModel(Placeholder(),
//       position: TimelineItemPosition.random,
//       iconBackground: Colors.redAccent,
//       icon: Icon(Icons.blur_circular)),
// ];
// return Timeline(children: items, position: TimelinePosition.Center);

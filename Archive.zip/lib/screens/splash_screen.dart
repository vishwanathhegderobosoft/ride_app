// import 'package:animated_splash_screen/animated_splash_screen.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import '../constants.dart';
// import 'intro_screen.dart';
//
// class SplashScreen extends StatelessWidget {
//   const SplashScreen({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: kSplashScreenDecoration,
//       child: AnimatedSplashScreen(
//         duration: 3000,
//         splash: "images/splash.png",
//         splashIconSize: 250,
//         backgroundColor: Colors.transparent,
//         nextScreen: IntroSlider(),
//       ),
//     );
//   }
// }

import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ride/screens/profile_header.dart';
import 'package:ride/screens/tool_kit.dart';
import 'package:timeline_node/timeline_node.dart';
import 'package:ride/screens/accessories_card.dart';
import 'package:ride/screens/profile_followers.dart';
import 'widgets/custom_button.dart';
import 'screens/service_card.dart';
import 'package:flutter/material.dart';
import 'screens/trip_summary_card.dart';
import 'screens/service_records_card.dart';
import 'screens/trip_card.dart';
import 'screens/check_slot.dart';
import 'package:dotted_line/dotted_line.dart';
import 'screens/encryption.dart';
import 'package:flutter/material.dart';
import 'package:timeline_node/timeline_node.dart';
import 'package:pdf/pdf.dart';

void main() => runApp(const MyApp());

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            actions: [
              Container(
                margin: EdgeInsets.only(right: 20),
                height: 30,
                width: 30,
                child: GestureDetector(
                  onTap: () {
                    encrypt();
                  },
                  child: Image.asset(
                    "images/invoice/download.png",
                  ),
                ),
              )
            ],
            elevation: 0,
            backgroundColor: Colors.transparent,
          ),
          body: Stack(
            children: [
              Image.asset(
                'images/invoice/invoice.png',
                fit: BoxFit.fill,
              ),
              Positioned(
                  child: Container(
                margin: EdgeInsets.all(40),
                //color: Colors.red,
                height: 600,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: [Text("Invoice"), Text("#0162")],
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Text("18 Nov,2017"),
                    SizedBox(
                      height: 40,
                    ),
                    Container(
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text("Rs 4,000/-"),
                          SizedBox(
                            height: 20,
                          ),
                          Container(
                            width: 80,
                            height: 30,
                            padding: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 3),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: Color(0xff19B692), width: 1.3)),
                            child: Center(
                              child: Text(
                                "√ Paid",
                                style: TextStyle(
                                    color: Color(0xff19B692),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    DottedLine(
                      direction: Axis.horizontal,
                      dashColor: Colors.black26,
                      lineThickness: 1,
                      dashLength: 8,
                      dashGapRadius: 0,
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    DottedLine(
                      direction: Axis.horizontal,
                      dashColor: Colors.black26,
                      lineThickness: 1,
                      dashLength: 8,
                      dashGapRadius: 0,
                    ),
                    SizedBox(
                      height: 20,
                    )
                  ],
                ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
